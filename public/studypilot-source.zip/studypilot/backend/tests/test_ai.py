import json
import httpx
import pytest
from .test_workflow import api, NOTES

@pytest.mark.parametrize('grounded',[True,False])
def test_validated_ai_generation(api,monkeypatch,grounded):
    import backend.main as module
    monkeypatch.setattr(module,'AI_KEY','fake-test-key')
    monkeypatch.setenv('AI_API_KEY','fake-test-key')
    monkeypatch.setenv('REQUIRE_AI','true')
    facts=module.extract_facts(NOTES)
    output={'facts':facts,'questions':module.demo_questions(facts)}
    output['questions'][0]['source_quote']=facts[0]['text'] if grounded else 'A claim absent from the notes.'
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            assert kwargs['headers']['Authorization']=='Bearer fake-test-key'
            assert kwargs['json']['max_tokens']==6000
            return httpx.Response(200,json={'choices':[{'message':{'content':json.dumps(output)}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    doc=api.post('/api/documents/text',json={'name':'AI notes','text':NOTES}).json()
    response=api.post('/api/study-kit/generate',json={'document_id':doc['id']})
    if grounded:
        assert response.status_code==200
        assert response.json()['mode']=='AI generated'
    else:
        assert response.status_code==502
        assert api.get('/api/state').json()['kits']==[]

@pytest.mark.parametrize('status,expected',[(400,'rejected the request'),(401,'rejected the API key'),(403,'denied access'),(404,'model or endpoint'),(429,'quota or rate limit'),(503,'temporarily unavailable')])
def test_provider_error_messages(monkeypatch,status,expected):
    import asyncio
    from fastapi import HTTPException
    import backend.main as module
    monkeypatch.setattr(module,'AI_KEY','private-test-key')
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            return httpx.Response(status,json={'error':{'message':'private-test-key confidential notes'}},request=httpx.Request('POST',url))
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    with pytest.raises(HTTPException) as error:asyncio.run(module.generate(NOTES))
    assert expected in error.value.detail
    assert 'private-test-key' not in error.value.detail
    assert 'confidential' not in error.value.detail

@pytest.mark.parametrize('finish_reason,valid',[('stop',True),('length',False)])
def test_gemini_schema_and_pdf_line_breaks(monkeypatch,finish_reason,valid):
    import asyncio
    from fastapi import HTTPException
    import backend.main as module
    monkeypatch.setattr(module,'AI_KEY','test')
    monkeypatch.setattr(module,'AI_URL','https://generativelanguage.googleapis.com/v1beta/openai')
    facts=module.extract_facts(NOTES)
    output={'facts':facts,'questions':module.demo_questions(facts)}
    # PDF whitespace may differ from the quotation without changing its words.
    text=NOTES.replace(' ', ' \n ')
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            assert url.endswith(':generateContent')
            assert kwargs['headers']=={'x-goog-api-key':'test'}
            assert 'properties' in kwargs['json']['generationConfig']['responseJsonSchema']
            assert kwargs['json']['generationConfig']['maxOutputTokens']==6000
            return httpx.Response(200,json={'candidates':[{'finishReason':'STOP' if valid else 'MAX_TOKENS','content':{'parts':[{'text':'```json\n'+json.dumps(output)+'\n```'}]}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    if valid:
        result=asyncio.run(module.generate(text))
        assert result[2]=='AI generated'
        assert len(result[1])==len(output['questions'])
    else:
        with pytest.raises(HTTPException,match='after one automatic retry'):asyncio.run(module.generate(text))

@pytest.mark.parametrize('error,expected',[
 ({'message':'Your API key was reported as leaked. secret'},'KEY_REPORTED_LEAKED'),
 ({'message':'Your project has been denied access. secret'},'PROJECT_ACCESS_DENIED'),
 ({'details':[{'reason':'API_KEY_SERVICE_BLOCKED','metadata':{'key':'secret'}}]},'API_KEY_SERVICE_BLOCKED'),
 ({'message':'secret','details':[{'reason':'secret'}]},'UNKNOWN'),
 ('secret','UNKNOWN')])
def test_safe_provider_diagnostic(error,expected):
    from backend.main import provider_diagnostic
    assert provider_diagnostic(httpx.Response(403,json={'error':error}))==expected

def test_gemini_schema_fallback(monkeypatch):
    import asyncio
    import backend.main as module
    monkeypatch.setattr(module,'AI_KEY','test')
    monkeypatch.setattr(module,'AI_URL','https://generativelanguage.googleapis.com/v1beta/openai')
    facts=module.extract_facts(NOTES)
    output={'facts':facts,'questions':module.demo_questions(facts)}
    calls=[]
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            calls.append(kwargs['json'])
            if len(calls)==1:
                return httpx.Response(400,json={'error':{'message':'Unsupported responseJsonSchema field'}},request=httpx.Request('POST',url))
            assert 'responseJsonSchema' not in kwargs['json']['generationConfig']
            assert 'Schema:' in kwargs['json']['systemInstruction']['parts'][0]['text']
            return httpx.Response(200,json={'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':json.dumps(output)}]}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    assert asyncio.run(module.generate(NOTES))[2]=='AI generated'
    assert len(calls)==2

def test_evidence_retry_recovers_without_saving_unverified_output(api,monkeypatch):
    import backend.main as module
    monkeypatch.setattr(module,'AI_KEY','test')
    facts=module.extract_facts(NOTES)
    calls=[]
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            calls.append(kwargs['json'])
            output={'facts':facts,'questions':module.demo_questions(facts)}
            if len(calls)==1:
                output['questions'][0]['source_quote']='This is not in the source.'
            else:
                assert 'previous attempt failed' in kwargs['json']['messages'][0]['content']
            return httpx.Response(200,json={'choices':[{'message':{'content':json.dumps(output)}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    doc=api.post('/api/documents/text',json={'name':'Retry notes','text':NOTES}).json()
    response=api.post('/api/study-kit/generate',json={'document_id':doc['id']})
    assert response.status_code==200
    assert len(calls)==2
    assert all(q['source_quote'] in NOTES for q in response.json()['questions'])

@pytest.mark.parametrize('failure',['json','missing_field','empty','wrong_shape','truncated','timeout','connection','server'])
def test_bounded_recovery(api,monkeypatch,failure):
    import asyncio
    import backend.main as module
    monkeypatch.setattr(module,'AI_KEY','test')
    monkeypatch.setattr(module,'AI_URL','https://example.com/v1')
    facts=module.extract_facts(NOTES)
    valid={'facts':facts,'questions':module.demo_questions(facts)}
    calls=[]
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            calls.append(1)
            req=httpx.Request('POST',url)
            if len(calls)==1:
                if failure=='timeout':raise httpx.ReadTimeout('timeout',request=req)
                if failure=='connection':raise httpx.ConnectError('connection',request=req)
                if failure=='server':return httpx.Response(503,json={},request=req)
                if failure=='wrong_shape':return httpx.Response(200,json={'choices':None},request=req)
                payload={'json':'{broken','empty':'','missing_field':'{"facts":[],"questions":[]}','truncated':json.dumps(valid)}[failure]
                return httpx.Response(200,json={'choices':[{'finish_reason':'length' if failure=='truncated' else 'stop','message':{'content':payload}}]},request=req)
            return httpx.Response(200,json={'choices':[{'message':{'content':json.dumps(valid)}}]},request=req)
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    assert asyncio.run(module.generate(NOTES))[2]=='AI generated'
    assert len(calls)==2

def test_format_failure_is_bounded_and_safe(api,monkeypatch,caplog):
    import asyncio
    import backend.main as module
    from fastapi import HTTPException
    monkeypatch.setattr(module,'AI_KEY','test')
    monkeypatch.setattr(module,'AI_URL','https://example.com/v1')
    calls=[]
    class Provider:
        def __init__(self,**kwargs):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kwargs):
            calls.append(1)
            return httpx.Response(200,json={'choices':[{'message':{'content':'private-invalid-output'}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr(module.httpx,'AsyncClient',Provider)
    with pytest.raises(HTTPException,match='after one automatic retry'):
        asyncio.run(module.generate(NOTES))
    assert len(calls)==2
    assert 'private-invalid-output' not in caplog.text

def test_question_metadata_normalization(api):
    import backend.main as module
    q=module.demo_questions(module.extract_facts(NOTES))[0]
    q.pop('id');q['difficulty']=' foundational ';q['level']='recall'
    parsed=module.Question.model_validate(q)
    assert parsed.id and parsed.difficulty=='Foundational' and parsed.level=='Recall'
    q['options']=['Same',' same ']
    with pytest.raises(ValueError):module.Question.model_validate(q)
    assert module.normalize_evidence('ofﬁce  text')==module.normalize_evidence('office text')
    assert module.normalize_evidence('not true')!=module.normalize_evidence('true')

def test_repeated_upload_and_generation_reuse_existing_kit(api,monkeypatch):
    import backend.main as module
    doc=api.post('/api/documents/text',json={'name':'Notes','text':NOTES}).json()
    again=api.post('/api/documents/text',json={'name':'Notes','text':NOTES}).json()
    assert doc['id']==again['id']
    kit=api.post('/api/study-kit/generate',json={'document_id':doc['id']}).json()
    async def fail(*args):raise AssertionError('must not regenerate')
    monkeypatch.setattr(module,'generate',fail)
    repeated=api.post('/api/study-kit/generate',json={'document_id':doc['id']}).json()
    assert repeated['id']==kit['id']
    assert len(api.get('/api/state').json()['kits'])==1

def test_concurrent_generation_guard_releases(api):
    from fastapi import HTTPException
    import backend.main as module
    user={'id':'test-guard'}
    with module.generation_slot(user):
        with pytest.raises(HTTPException,match='already being generated'):
            with module.generation_slot(user):pass
    with module.generation_slot(user):pass
